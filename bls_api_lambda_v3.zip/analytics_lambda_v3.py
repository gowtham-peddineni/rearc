import boto3
import json
import urllib.parse

def lambda_handler(event, context):
    s3 = boto3.client('s3')
    

    for sqs_record in event['Records']:
        try:
            s3_event_str = sqs_record['body']
            s3_event = json.loads(s3_event_str)
  
            if 'Records' in s3_event:
                for s3_record in s3_event['Records']:
                    bucket_name = s3_record['s3']['bucket']['name']
                    file_key = urllib.parse.unquote_plus(s3_record['s3']['object']['key'])
                    
                    print(f"Processing triggered file: s3://{bucket_name}/{file_key}")
                   
                    process_data(s3, bucket_name, file_key)
                    
            else:
                print("SQS message did not contain S3 records (Test event?)")

        except Exception as e:
            print(f"Error processing SQS record: {str(e)}")
            raise e

    return {"statusCode": 200, "body": "Processing Complete"}

def process_data(s3, target_bucket, target_key):
    
    print("Reading Population Data (From Trigger)")
    obj_pop = s3.get_object(Bucket=target_bucket, Key=target_key)
    raw_pop_data = json.loads(obj_pop['Body'].read().decode('utf-8'))
    
    population_list = raw_pop_data.get('data', [])
    pop_lookup = {str(item['Year']): item['Population'] for item in population_list}

    print("Reading BLS Data")
    bls_bucket = "bls-time-series-gp"
    bls_key = "pr/pr.data.0.Current"
    
    obj_bls = s3.get_object(Bucket=bls_bucket, Key=bls_key)
    bls_text = obj_bls['Body'].read().decode('utf-8')
    
    bls_clean = []
    lines = bls_text.strip().split('\n')
    headers = lines[0].split()
    
    idx_series = headers.index('series_id')
    idx_year   = headers.index('year')
    idx_period = headers.index('period')
    idx_value  = headers.index('value')
        
    for line in lines[1:]:
        parts = line.split()
        if len(parts) < 4: continue
        
        bls_clean.append({
            'series_id': parts[idx_series],
            'year':      parts[idx_year],
            'period':    parts[idx_period],
            'value':     parts[idx_value]
        })

    print("Generating Report")
    df_report = []
    
    for bls_row in bls_clean:
        join_key = str(bls_row['year'])
        population_value = pop_lookup.get(join_key, None)
        
        df_report.append({
            'series_id':  bls_row['series_id'],
            'period':     bls_row['period'],
            'value':      bls_row['value'],
            'year':       bls_row['year'],
            'Population': population_value
        })

    print(f"Report Generated. Total rows: {len(df_report)}")
    # Optional: Print first 2 rows to confirm
    print(json.dumps(df_report, indent=2))

    

