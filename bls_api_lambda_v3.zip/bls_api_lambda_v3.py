import json
import boto3
import urllib.request
import urllib.error
import re
import os
from datetime import datetime

# --- CONFIGURATION ---
# Data USA Config
DATA_USA_URL = "https://honolulu-api.datausa.io/tesseract/data.jsonrecords?cube=acs_yg_total_population_1&drilldowns=Year%2CNation&locale=en&measures=Population"
DATA_USA_BUCKET = "data-usa-v3"

# BLS Config
BLS_SOURCE_URL = "https://download.bls.gov/pub/time.series/pr/"
BLS_BUCKET = "bls-time-series-gp-v3"
BLS_USER_AGENT = "bls-time-series/gp1 (gowthampix96@gmail.com)"
BLS_S3_PREFIX = "pr/"

s3 = boto3.client('s3')

def process_data_usa():
    print("Starting Data USA Task")
    s3_file_name = f"population_data{datetime.now().strftime('%d%m%Y')}.json"
    
    try:
        req = urllib.request.Request(DATA_USA_URL, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req) as response:
            if response.getcode() != 200:
                raise Exception(f"Data USA API failed with status {response.getcode()}")
            data = json.loads(response.read().decode('utf-8'))
        
        s3.put_object(
            Bucket=DATA_USA_BUCKET,
            Key=s3_file_name,
            Body=json.dumps(data),
            ContentType='application/json'
        )
        print(f"Successfully uploaded {s3_file_name} to {DATA_USA_BUCKET}")
        return True
    except Exception as e:
        print(f"Error in Data USA process: {e}")
        return False

def get_remote_bls_files():
    req = urllib.request.Request(BLS_SOURCE_URL, headers={'User-Agent': BLS_USER_AGENT})
    try:
        with urllib.request.urlopen(req) as response:
            html = response.read().decode('utf-8')
    except Exception as e:
        print(f"Error accessing BLS website: {e}")
        return {}

    files = {}
    pattern = re.compile(r'href=["\'](.*?)["\']', re.IGNORECASE)
    
    for match in pattern.finditer(html):
        raw_link = match.group(1)
        filename = raw_link.split('/')[-1]

        if not filename or filename in ['Name', 'Last modified', 'Size', 'Description', 'Parent Directory'] or filename.startswith('?') or raw_link in ['../', './']:
            continue

        file_url = raw_link if raw_link.startswith('http') else (BLS_SOURCE_URL + filename)

        try:
            head_req = urllib.request.Request(file_url, headers={'User-Agent': BLS_USER_AGENT}, method='HEAD')
            with urllib.request.urlopen(head_req) as head_res:
                source_etag = (head_res.headers.get('ETag') or "").replace('"', '')
                last_mod = head_res.headers.get('Last-Modified')
                files[filename] = {
                    'unique_id': source_etag if source_etag else last_mod,
                    'url': file_url
                }
        except Exception as e:
            print(f"Failed to HEAD {filename}: {e}")
            
    return files

def process_bls_sync():
    print("Starting BLS Sync Task")
    try:
        remote_files = get_remote_bls_files()
        
        s3_files = {}
        paginator = s3.get_paginator('list_objects_v2')
        for page in paginator.paginate(Bucket=BLS_BUCKET, Prefix=BLS_S3_PREFIX):
            for obj in page.get('Contents', []):
                fname = obj['Key'].replace(BLS_S3_PREFIX, "")
                s3_files[fname] = obj['Key']

        for filename, meta in remote_files.items():
            s3_key = BLS_S3_PREFIX + filename
            should_upload = False
            
            if filename not in s3_files:
                should_upload = True
            else:
                try:
                    s3_obj = s3.head_object(Bucket=BLS_BUCKET, Key=s3_key)
                    if s3_obj.get('Metadata', {}).get('source-unique-id') != str(meta['unique_id']):
                        should_upload = True
                except:
                    should_upload = True
            
            if should_upload:
                print(f"Syncing BLS file: {filename}")
                with urllib.request.urlopen(urllib.request.Request(meta['url'], headers={'User-Agent': BLS_USER_AGENT})) as res:
                    s3.upload_fileobj(res, BLS_BUCKET, s3_key, ExtraArgs={'Metadata': {'source-unique-id': str(meta['unique_id'])}})

        for filename in s3_files:
            if filename not in remote_files:
                print(f"Deleting stale BLS file: {filename}")
                s3.delete_object(Bucket=BLS_BUCKET, Key=BLS_S3_PREFIX + filename)
        
        return True
    except Exception as e:
        print(f"Error in BLS Sync: {e}")
        return False

def lambda_handler(event, context):
    success_usa = process_data_usa()
    success_bls = process_bls_sync()
    
    status_code = 200 if (success_usa and success_bls) else 207 
    
    return {
        'statusCode': status_code,
        'body': json.dumps({
            'data_usa_success': success_usa,
            'bls_sync_success': success_bls
        })
    }